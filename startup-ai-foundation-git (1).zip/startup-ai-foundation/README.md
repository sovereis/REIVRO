# AI Developer Tools — Foundation

Initial Git repository structure for a planned 2027 AI developer productivity startup.

Current scope: directory organization and project context only. No production-ready agents, skills, server, or workflows are shipped here.

Read [CONTEXTO.md](CONTEXTO.md) for project context and status.

## Directories

- `skills/` — future skills
- `servidor/` — future backend and integrations
- `testes/` — future automated tests
- `aprovacao/` — future approval and safety policies

## PowerShell

After cloning or extracting the repository:

```powershell
Get-Content .\CONTEXTO.md
```
