# CONTEXTO — Startup AI Developer Tools (2027)

## Visão do produto

Startup voltada a desenvolvedores e programadores que usam inteligência artificial, com mercado-alvo nos Estados Unidos e horizonte de lançamento em 2027. O objetivo é oferecer um ecossistema modular para aumentar produtividade e gerar resultados verificáveis em engenharia de software.

## Princípios

- A experiência do cliente não deve exigir uma única sequência: ele poderá começar por skills, comandos, agentes ou conteúdos, quando esses recursos existirem.
- Buscar compatibilidade com diferentes agentes e ferramentas de código; não presumir que um único formato seja universal.
- Projetar permissões mínimas, aprovações para ações sensíveis e verificações baseadas em evidências.
- Distinguir ideias planejadas de implementações efetivamente testadas.
- Documentação de produto para clientes americanos será preferencialmente em inglês.

## Estado confirmado (17 de novembro de 2026)

- **Skills:** há ideias e estrutura conceitual para mais de 80 skills; elas não estão todas implementadas. Não inventar catálogo de skills.
- **Agentes:** mais de 50 agentes fazem parte da visão, porém os papéis individuais ainda não foram planejados.
- **Comandos:** o protótipo local `/skill-match` v0.1.0 foi executado com sucesso no PowerShell usando catálogo demonstrativo, com ranking por termos e filtro de permissões. Ele **não está incluído neste repositório inicial**.
- **Comandos futuros:** `/plan`, `/impact`, `/verify` e `/mission` ainda não estão entregues ou validados neste repositório. Desenvolvimento de comandos foi adiado enquanto as skills são estruturadas.
- **Workflows de clientes:** serão desenhados futuramente.
- **Videoaulas:** ainda não produzidas.

## Estrutura inicial

- `skills/` — futuras definições de skills e seus recursos.
- `servidor/` — futuro servidor, APIs e integrações.
- `testes/` — futuros testes automatizados e de integração.
- `aprovacao/` — futuras regras de aprovação, revisões e políticas de execução.
- `CONTEXTO.md` — contexto e decisões do projeto.

## Próximos passos

1. Consolidar catálogo das ideias de skills, com estados como `planned`, `testing`, `ready`.
2. Definir esquema e padrão de documentação para uma skill.
3. Implementar e validar um pequeno conjunto inicial de skills.
4. Retomar comandos, sem depender de agentes próprios.
5. Projetar agentes, workflows, materiais educativos e mecanismos de distribuição.

## Limites deste repositório

Este é somente o **esqueleto inicial**. As pastas não significam componentes implementados, e nenhum código de execução de agentes, servidor ou mecanismo de aprovação foi criado aqui.
